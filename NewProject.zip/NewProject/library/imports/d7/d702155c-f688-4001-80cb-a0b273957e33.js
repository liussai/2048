"use strict";
cc._RF.push(module, 'd7021Vc9ohAAYDLoLJzlX4z', 'item');
// Script/item.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        _score: null,
        _indexPos: cc.v2(0, 0),
        result_sprite: cc.Sprite,
        resultSpriteArr: [cc.SpriteFrame],
        LabelName: cc.Label
    },

    start: function start() {},
    setData: function setData(score) {
        // console.log("****************"+score)
        //         console.log("****************"+Math.log(score)/Math.log(2))
        this._score = score;
        this.result_sprite.spriteFrame = this.resultSpriteArr[Math.log(score) / Math.log(2) - 1];
        var name = ["筑基", "开光", "融合", "心动", "金丹", "元婴", "出窍", "分身", "合体", "大乘", "渡劫"];
        // console.log(this.node)
        this.LabelName.string = name[Math.log(score) / Math.log(2) - 1];
    }

    // update (dt) {},

});

cc._RF.pop();