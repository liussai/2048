"use strict";
cc._RF.push(module, '0aee2l76xBA0a4Q3QXt7KXH', 'gameStar');
// Script/gameStar.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        btn_rank: cc.Node,
        btn_star: cc.Node,
        rankingScrollView: cc.Sprite,
        isRank: false
    },

    // onLoad () {},

    start: function start() {
        this.tex = new cc.Texture2D();
        window.sharedCanvas = null;
    },
    friendButtonFunc: function friendButtonFunc(event) {
        window.wx.postMessage({
            messageType: 1
        });
    },

    // 刷新子域的纹理
    _updateSubDomainCanvas: function _updateSubDomainCanvas() {
        var that = this;
        if (window.sharedCanvas != undefined) {
            that.tex.initWithElement(window.sharedCanvas);
            that.tex.handleLoadedTexture();
            that.rankingScrollView.spriteFrame = new cc.SpriteFrame(that.tex);
        }
    },
    impower: function impower() {
        //授权
        var that = this;
        wx.getSetting({
            success: function success(res) {
                if (res.userInfo) {
                    console.log("获取数据成功", res);
                } else {
                    that.wxAPI();
                }
            },
            fail: function fail() {
                that.wxAPI();
            }
        });
    },
    getRank: function getRank() {
        //获得排名
        var that = this;
        var openDataContext = wx.getOpenDataContext();
        window.sharedCanvas = openDataContext.canvas;
        if (!that.isRank) {
            console.log("显示排行榜");
            that.isRank = true;
            that.rankingScrollView.active = true;
            // wx.setUserCloudStorage({
            //    KVDataList:[{key:'score',value:'60'},{key:'time',value:'40'}],
            // })
            wx.showShareMenu({ withShareTicket: true }); //设置分享按钮，方便获取群id展示群排行榜
            openDataContext.postMessage({
                type: 1
            });
        } else {
            console.log("隐藏排行榜");
            that.isRank = false;
            that.rankingScrollView.active = false;
            openDataContext.postMessage({
                type: 2
            });
        }
    },
    wxAPI: function wxAPI() {
        console.log("获取数据失败，通过button发起数据请求");
        var button = wx.createUserInfoButton({
            type: 'text',
            text: '获取用户信息',
            style: {
                left: 50,
                top: 50,
                width: 50,
                height: 20,
                lineHeight: 20,
                backgroundColor: '#781C18',
                color: '#000f00',
                textAlign: 'center',
                fontSize: 10,
                borderRadius: 4
            }
        });
        button.onTap(function (res) {
            console.log("数据请求成功");
            console.log(res);
        });
    },
    update: function update() {
        this._updateSubDomainCanvas();
    },
    star: function star() {
        cc.director.loadScene('game');
    }
    // update (dt) {},

});

cc._RF.pop();