[
  {
    "__type__": "cc.SceneAsset",
    "_name": "",
    "_objFlags": 0,
    "_native": "",
    "scene": {
      "__id__": 1
    }
  },
  {
    "__type__": "cc.Scene",
    "_objFlags": 0,
    "_parent": null,
    "_children": [
      {
        "__id__": 2
      }
    ],
    "_active": true,
    "_level": 0,
    "_components": [],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 0,
      "height": 0
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0,
      "y": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 0.264254510140345,
      "y": 0.264254510140345,
      "z": 1
    },
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "4cG0fsaZdC0bIIGey6VPQu"
  },
  {
    "__type__": "cc.Node",
    "_name": "Canvas",
    "_objFlags": 0,
    "_parent": {
      "__id__": 1
    },
    "_children": [
      {
        "__id__": 3
      },
      {
        "__id__": 5
      },
      {
        "__id__": 11
      }
    ],
    "_active": true,
    "_level": 1,
    "_components": [
      {
        "__id__": 17
      },
      {
        "__id__": 18
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 640,
      "height": 960
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": 320,
      "y": 480,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "d5xrayLnhJp7KxaH3CUihD"
  },
  {
    "__type__": "cc.Node",
    "_name": "Main Camera",
    "_objFlags": 0,
    "_parent": {
      "__id__": 2
    },
    "_children": [],
    "_active": true,
    "_level": 2,
    "_components": [
      {
        "__id__": 4
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 0,
      "height": 0
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": 0,
      "y": 0,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "b4JXpqh5dPponBSnaHIpVw"
  },
  {
    "__type__": "cc.Camera",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 3
    },
    "_enabled": true,
    "_cullingMask": 4294967295,
    "_clearFlags": 7,
    "_backgroundColor": {
      "__type__": "cc.Color",
      "r": 0,
      "g": 0,
      "b": 0,
      "a": 255
    },
    "_depth": -1,
    "_zoomRatio": 1,
    "_targetTexture": null,
    "_id": "9fNhnAb5dAs67EuP0JIwWR"
  },
  {
    "__type__": "cc.Node",
    "_name": "bg",
    "_objFlags": 0,
    "_parent": {
      "__id__": 2
    },
    "_children": [
      {
        "__id__": 6
      },
      {
        "__id__": 8
      }
    ],
    "_active": true,
    "_level": 2,
    "_components": [
      {
        "__id__": 10
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 540,
      "height": 960
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0,
      "y": 0
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": -270,
      "y": -480,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "d7GBCwphtJaoY3UPZq1zMf"
  },
  {
    "__type__": "cc.Node",
    "_name": "score",
    "_objFlags": 0,
    "_parent": {
      "__id__": 5
    },
    "_children": [],
    "_active": true,
    "_level": 2,
    "_components": [
      {
        "__id__": 7
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 23.36,
      "height": 40
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 1,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": 443,
      "y": 845,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "56AOAY1lRNbLCp8V7qLU+I"
  },
  {
    "__type__": "cc.Label",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 6
    },
    "_enabled": true,
    "_srcBlendFactor": 1,
    "_dstBlendFactor": 771,
    "_useOriginalSize": false,
    "_string": "0",
    "_N$string": "0",
    "_fontSize": 42,
    "_lineHeight": 40,
    "_enableWrapText": true,
    "_N$file": null,
    "_isSystemFontUsed": true,
    "_spacingX": 0,
    "_N$horizontalAlign": 1,
    "_N$verticalAlign": 1,
    "_N$fontFamily": "Arial",
    "_N$overflow": 0,
    "_id": "1efuhRg19LSqS8mnsTyOfJ"
  },
  {
    "__type__": "cc.Node",
    "_name": "scoreTitle",
    "_objFlags": 0,
    "_parent": {
      "__id__": 5
    },
    "_children": [],
    "_active": true,
    "_level": 2,
    "_components": [
      {
        "__id__": 9
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 132,
      "height": 40
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": 138,
      "y": 845,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "a4BOaWAr9CH48btRBRujAW"
  },
  {
    "__type__": "cc.Label",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 8
    },
    "_enabled": true,
    "_srcBlendFactor": 1,
    "_dstBlendFactor": 771,
    "_useOriginalSize": false,
    "_string": "得分：",
    "_N$string": "得分：",
    "_fontSize": 44,
    "_lineHeight": 40,
    "_enableWrapText": true,
    "_N$file": null,
    "_isSystemFontUsed": true,
    "_spacingX": 0,
    "_N$horizontalAlign": 1,
    "_N$verticalAlign": 1,
    "_N$fontFamily": "Arial",
    "_N$overflow": 0,
    "_id": "3f1b5vrnNMHZm7E5q1/URp"
  },
  {
    "__type__": "cc.Sprite",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 5
    },
    "_enabled": true,
    "_srcBlendFactor": 770,
    "_dstBlendFactor": 771,
    "_spriteFrame": {
      "__uuid__": "1c85d6d1-e0e3-4592-a252-61a5a1ea8c4d"
    },
    "_type": 0,
    "_sizeMode": 1,
    "_fillType": 0,
    "_fillCenter": {
      "__type__": "cc.Vec2",
      "x": 0,
      "y": 0
    },
    "_fillStart": 0,
    "_fillRange": 0,
    "_isTrimmedMode": true,
    "_state": 0,
    "_atlas": null,
    "_id": "a1exJ5Aq5K7aJ+7SC7kWl9"
  },
  {
    "__type__": "cc.Node",
    "_name": "item",
    "_objFlags": 0,
    "_parent": {
      "__id__": 2
    },
    "_children": [
      {
        "__id__": 12
      },
      {
        "__id__": 14
      }
    ],
    "_active": true,
    "_level": 2,
    "_components": [
      {
        "__id__": 16
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 0,
      "height": 0
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": 0,
      "y": 0,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "9fo7kAy45InK6vxsgJ3+WY"
  },
  {
    "__type__": "cc.Node",
    "_name": "num_img",
    "_objFlags": 0,
    "_parent": {
      "__id__": 11
    },
    "_children": [],
    "_active": true,
    "_level": 3,
    "_components": [
      {
        "__id__": 13
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 107,
      "height": 136
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": -183,
      "y": 146,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "edM5x0ceBB5q2yw+45vKep"
  },
  {
    "__type__": "cc.Sprite",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 12
    },
    "_enabled": true,
    "_srcBlendFactor": 770,
    "_dstBlendFactor": 771,
    "_spriteFrame": {
      "__uuid__": "00946029-dae6-4f73-b9a4-94db6967913b"
    },
    "_type": 0,
    "_sizeMode": 1,
    "_fillType": 0,
    "_fillCenter": {
      "__type__": "cc.Vec2",
      "x": 0,
      "y": 0
    },
    "_fillStart": 0,
    "_fillRange": 0,
    "_isTrimmedMode": true,
    "_state": 0,
    "_atlas": {
      "__uuid__": "06ecfb77-13a7-401b-a45f-18873cf41f0f"
    },
    "_id": "80QN5kv+JJ07M88Er1Rpw+"
  },
  {
    "__type__": "cc.Node",
    "_name": "score",
    "_objFlags": 0,
    "_parent": {
      "__id__": 11
    },
    "_children": [],
    "_active": true,
    "_level": 3,
    "_components": [
      {
        "__id__": 15
      }
    ],
    "_prefab": null,
    "_opacity": 255,
    "_color": {
      "__type__": "cc.Color",
      "r": 255,
      "g": 255,
      "b": 255,
      "a": 255
    },
    "_contentSize": {
      "__type__": "cc.Size",
      "width": 97.87,
      "height": 40
    },
    "_anchorPoint": {
      "__type__": "cc.Vec2",
      "x": 0.5,
      "y": 0.5
    },
    "_position": {
      "__type__": "cc.Vec3",
      "x": -166,
      "y": 129,
      "z": 0
    },
    "_scale": {
      "__type__": "cc.Vec3",
      "x": 1,
      "y": 1,
      "z": 1
    },
    "_rotationX": 0,
    "_rotationY": 0,
    "_quat": {
      "__type__": "cc.Quat",
      "x": 0,
      "y": 0,
      "z": 0,
      "w": 1
    },
    "_skewX": 0,
    "_skewY": 0,
    "_zIndex": 0,
    "groupIndex": 0,
    "_id": "1bxZgckMBPeLqqDaZrtdH5"
  },
  {
    "__type__": "cc.Label",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 14
    },
    "_enabled": true,
    "_srcBlendFactor": 1,
    "_dstBlendFactor": 771,
    "_useOriginalSize": false,
    "_string": "Label",
    "_N$string": "Label",
    "_fontSize": 40,
    "_lineHeight": 40,
    "_enableWrapText": true,
    "_N$file": null,
    "_isSystemFontUsed": true,
    "_spacingX": 0,
    "_N$horizontalAlign": 1,
    "_N$verticalAlign": 1,
    "_N$fontFamily": "Arial",
    "_N$overflow": 0,
    "_id": "6985LDmLlCELEXYmdnfnE8"
  },
  {
    "__type__": "f09f74zwFBPAbPAsGI6B0Mr",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 11
    },
    "_enabled": true,
    "_score": 0,
    "_size": null,
    "_indexPos": {
      "__type__": "cc.Vec2",
      "x": 0,
      "y": 0
    },
    "_img": null,
    "_id": "00s6GJ9g5Lc7VXH3Iwn0gB"
  },
  {
    "__type__": "cc.Canvas",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 2
    },
    "_enabled": true,
    "_designResolution": {
      "__type__": "cc.Size",
      "width": 640,
      "height": 960
    },
    "_fitWidth": false,
    "_fitHeight": true,
    "_id": "26moKNb7FMYY6LUhiY/LH2"
  },
  {
    "__type__": "280c3rsZJJKnZ9RqbALVwtK",
    "_name": "",
    "_objFlags": 0,
    "node": {
      "__id__": 2
    },
    "_enabled": true,
    "_gameCtrl": null,
    "_startCtrl": null,
    "_tipsCtrl": null,
    "_resetLayer": null,
    "_spriteNode": null,
    "_listener": null,
    "_touch": false,
    "_direction": 0,
    "_resultLayer": null,
    "_moveAudio": null,
    "_mergeAudio": null,
    "_reStart": false,
    "_celebrate": [],
    "_hang": 4,
    "_lie": 4,
    "map": [],
    "emptyMap": [],
    "_id": "81yFkOEyJFhIWjcM3hOlAG"
  }
]