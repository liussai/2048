(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/item.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd7021Vc9ohAAYDLoLJzlX4z', 'item', __filename);
// Script/item.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        _score: null,
        _indexPos: cc.v2(0, 0),
        result_sprite: cc.Sprite,
        resultSpriteArr: [cc.SpriteFrame],
        LabelName: cc.Label
    },

    start: function start() {},
    setData: function setData(score) {
        // console.log("****************"+score)
        //         console.log("****************"+Math.log(score)/Math.log(2))
        this._score = score;
        this.result_sprite.spriteFrame = this.resultSpriteArr[Math.log(score) / Math.log(2) - 1];
        var name = ["筑基", "开光", "融合", "心动", "金丹", "元婴", "出窍", "分身", "合体", "大乘", "渡劫"];
        // console.log(this.node)
        this.LabelName.string = name[Math.log(score) / Math.log(2) - 1];
    }

    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=item.js.map
        