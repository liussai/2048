var DIRECTION={
    NONE:0,
    UP:1,
    DOWN:2,
    LEFT:3,
    RIGHT:4
};
var GAMESTATE={
    WAIT:0,
    START:1,
    END:2
}
cc.Class({
    extends: cc.Component,

    properties: {
        spriteNode:cc.Sprite,
        _touch:false,
        _direction:DIRECTION.NONE,
        _state:GAMESTATE.WAIT,
        resultLayer:null,
        _mergeAudio:null,
        _reStart:false,
        _celebrate:[],
        hang:4,
        lie:4,
        map:[],
        emptyMap:[],
        item:cc.Prefab,
        btn_back:cc.Node,
        btn_wx:cc.Node,
        rankingScrollView:cc.Sprite
    },
    initMap:function () {
        // var mapObj=JSON.parse(cc.sys.localStorage.getItem("map"));
        // if(!mapObj||this.getMapLength(mapObj.map)==0)
        // {
            for(var i=0;i<this.hang;i++)
            {
                this.map[i]=new Array();
                for(var j=0;j<this.lie;j++)
                {
                    this.map[i].push(null);
                    this.emptyMap.push({hang:i,lie:j});   
                }
            }
            var random=this.getSeedRandom(0,100);
            var score=random>=70?4:2;
            var ihang=parseInt(3*Math.random())
            var jlie=parseInt(3*Math.random())
            var block = cc.instantiate(this.item);
            block.getComponent("item").setData(score)
            block.setPosition(85+jlie*124.5,198+145*ihang);
            console.log(block.getComponent("item")._score)
            this.map[ihang][jlie]=block;
            this.spriteNode.node.addChild(block,1000);
        // }else
        // {
        //     this._reStart=true;
        //     this._celebrate=mapObj.celebrate;
        //     for(var i=0;i<this.hang;i++)
        //     {
        //         this.map[i]=new Array();
        //         // this._localStorageObj.map[i]=new Array();
        //         for(var j=0;j<this.lie;j++)
        //         {
        //             var score=mapObj.map[i][j];
        //             if(score)
        //             {
        //                 var block=new Block(score);
        //                 block.setPosition(85+jlie*124.5,198+145*ihang);
        //                 this.spriteNode.node.addChild(block,1000);
        //                 this.map[i][j]=block;
        //             }else
        //             {
        //                 this.map[i][j]=null;
        //             }

        //         }
        //     }
            // this._localStorageObj.map=this.getMapScore();
            this.resetEmptyMap(this.emptyMap);
        // }

    },
    resetEmptyMap:function () {
        this.emptyMap=[];
        for(var i=0;i<this.hang;i++)
        {
            for(var j=0;j<this.lie;j++)
            {
                if(this.map[i][j]===null)
                {
                    this.emptyMap.push({hang:i,lie:j});
                }
            }
        }
    },
    /**
     * 判断能否向上走
     */
    canGoUp:function () {
        for(var i=0;i<this.hang-1;i++)
        {
            for(var j=0;j<this.lie;j++)
            {
                var block=this.map[i][j];
                var upBlock=this.map[i+1][j];
                if(block)
                {
                    if(!upBlock)
                    {
                        return true;
                    }else
                    {
                        if(upBlock.getComponent("item")._score==block.getComponent("item")._score)
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },
    /**
     * 判断能否向下走
     */
    canGoDown:function () {
        for(var i=1;i<this.hang;i++)
        {
            for(var j=0;j<this.lie;j++)
            {
                var block=this.map[i][j];
                var downBlock=this.map[i-1][j];
                if(block)
                {
                    if(!downBlock)
                    {
                        return true;
                    }else
                    {
                        if(downBlock.getComponent("item")._score==block.getComponent("item")._score)
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },
    /**
     * 判断能否向左走
     */
    canGoLeft:function () {
        
        for(var i=0;i<this.hang;i++)
        {
            for(var j=1;j<this.lie;j++)
            {
                var block=this.map[i][j];
                var leftBlock=this.map[i][j-1];
                if(block)
                {
                    if(!leftBlock)
                    {
                        return true;
                    }else
                    {
                        if(leftBlock.getComponent("item")._score==block.getComponent("item")._score)
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },
    /**
     * 判断能否向右走
     */
    canGoRight:function () {
        for(var i=0;i<this.hang;i++)
        {
            for(var j=0;j<this.lie-1;j++)
            {
                var block=this.map[i][j];
                var rightBlock=this.map[i][j+1];
                if(block)
                {
                    if(!rightBlock)
                    {
                        return true;
                    }else
                    {
                        if(rightBlock.getComponent("item")._score==block.getComponent("item")._score)
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },
    /**
     * 判断能走么
     * @param direction
     */
    canGo:function (direction) {
        switch (direction)
        {
            case DIRECTION.UP:
                return this.canGoUp();
                break;
            case DIRECTION.DOWN:
                return this.canGoDown();
                break;
            case DIRECTION.LEFT:
                return this.canGoLeft();
                break;
            case DIRECTION.RIGHT:
                return this.canGoRight();
                break;
            case DIRECTION.NONE:
                return false;
                break;
        }
    },
    go:function (direction) {
        if(direction)
        {
            if(this.canGo(direction))
            {
                this.move(direction);
                this.merge(direction);
                this.resetEmptyMap();
                this.createBlockByNum(1);
                // this.updateScore();
                // this.updateLocalStorageObj(this.getMapScore(),SF_INFO.currScore,SF_INFO.bestScore,this._celebrate);
            }
        }
    },
     /**
     * 移动
     */
    move:function (dirction) {
        var blockArr = this.getBlockArr();
        var line=[];
        switch (dirction)
        {
            case DIRECTION.UP:
                for (var i = 0;  i < this.hang; i++) {
                    line = blockArr.filter(function (item) {
                        return item.indexArr[1] === i;//返回同列中不为空的数据，从第一列开始
                    });
                    for (var j = 0; j < line.length; j++) {
                        line[line.length-1-j].block.stopAllActions();
                        if(!cc.Vec2(pos,line[line.length-1-j].block._indexPos))
                        {
                            // 85+jlie*124.5,198+145*ihang
                            this.map[line[line.length-1-j].indexArr[0]][line[line.length-1-j].indexArr[1]] = null;
                            this.map[this.hang-1-j][line[line.length-1-j].indexArr[1]] = line[line.length-1-j].block;
                            var pos=cc.p(85+124.5*line[line.length-1-j].indexArr[1],198+145*(this.hang-1-j));
                            line[line.length-1-j].block.stopActionByTag(123);
                            line[line.length-1-j].block._indexPos=pos;
                            var action=cc.moveTo(0.1,pos);
                            action.setTag(123);
                            line[line.length-1-j].block.runAction(action);

                        }else
                        {
                            cc.log("数据错啦");
                        }

                    }
                }
                // console.log(this.map)
                break;
            case DIRECTION.DOWN:
                for (var i = 0;  i < this.hang; i++) {
                    line = blockArr.filter(function (item) {
                        return item.indexArr[1] === i;
                    });
                    for (var j = 0; j < line.length; j++) {
                        line[j].block.stopAllActions();
                        if(!cc.Vec2(pos,line[j].block._indexPos))
                        {
                            this.map[line[j].indexArr[0]][line[j].indexArr[1]] = null;
                            this.map[j][i] = line[j].block;
                            var pos=cc.p(85+124.5*i,198+145*j);
                            line[j].block.stopActionByTag(456);
                            line[j].block._indexPos=pos;
                            var action=cc.moveTo(0.1,pos);
                            action.setTag(456);
                            line[j].block.runAction(action);
                        }
                    }
                }
                // console.log(this.map)
                break;
            case DIRECTION.LEFT:
                for (var i = 0;  i < this.hang; i++) {
                    line=blockArr.filter(function(item){
                        return item.indexArr[0]===i;
                    })
                  
                    for (var j = 0; j < line.length; j++) {
                        line[j].block.stopAllActions();
                        if(!cc.Vec2(pos,line[j].block._indexPos))
                        {
                            this.map[line[j].indexArr[0]][line[j].indexArr[1]] = null;
                            this.map[i][j] = line[j].block;
                            var pos=cc.p(85+124.5*j,198+145*i);
                            line[j].block.stopActionByTag(789);
                            line[j].block._indexPos=pos;
                            var action=cc.moveTo(0.1,pos);
                            action.setTag(789);
                            line[j].block.runAction(action);
                        }
                    }
                }
                break;
            case DIRECTION.RIGHT:
                for (var i = 0;  i < this.hang; i++) {
                    line = blockArr.filter(function (item) {
                        return item.indexArr[0] === i;
                    });
                    for (var j = 0; j < line.length; j++) {
                        line[line.length-1-j].block.stopAllActions();
                        if(!cc.Vec2(pos,line[line.length-1-j].block._indexPos))
                        {
                            this.map[line[line.length-1-j].indexArr[0]][line[line.length-1-j].indexArr[1]] = null;
                            this.map[i][this.hang-1-j] = line[line.length-1-j].block;
                            var pos=cc.p(85+124.5*(this.lie-1-j),198+145*i);
                            line[line.length-1-j].block.stopActionByTag(145);
                            line[line.length-1-j].block._indexPos=pos;
                            var action=cc.moveTo(0.1,pos);
                            action.setTag(145);
                            line[line.length-1-j].block.runAction(action);
                        }
                    }
                }
                // console.log(this.map)
                break;
        }
    },
     /**
     * 合并
     * @param direction
     */
    merge:function (direction) {
        switch (direction)
        {
            case DIRECTION.UP:
                for (var i =  this.hang-1; i >0; i--) {
                    for (var j = 0; j < this.lie; j++) {
                        if (this.map[i][j]&&this.map[i-1][j]) {
                            // console.log(this.map[i][j].getComponent("item")._score+"*********"+this.map[i-1][j].getComponent("item")._score) 
                            if(this.map[i][j].getComponent("item")._score === this.map[i-1][j].getComponent("item")._score)
                            {
                                this.map[i][j].getComponent("item")._score *= 2;
                                var pos=cc.p(85+124.5*j,198+145*i);
                                this.map[i-1][j].stopAllActions();
                                this.map[i-1][j].runAction(cc.sequence(cc.moveTo(0.1,pos),cc.removeSelf(true)));
                                this.map[i-1][j]=null;
                                console.log(this.map[i][j].getComponent("item")._score) 
                                this.map[i][j].getComponent("item").setData(this.map[i][j].getComponent("item")._score) 
                            }
                        }
                    }
                }
                this.move(direction);
                break;
            case DIRECTION.DOWN:
                for (var i = 0; i < this.hang-1; i++) {
                    for (var j = 0; j <this.lie ; j++) {
                        if (this.map[i][j]&&this.map[i+1][j]) {
                            // console.log(this.map[i][j].getComponent("item")._score+"*********"+this.map[i+1][j].getComponent("item")._score) 
                            if(this.map[i][j].getComponent("item")._score === this.map[i+1][j].getComponent("item")._score)
                            {
                                this.map[i][j].getComponent("item")._score *= 2;
                                var pos=cc.p(85+124.5*j,198+145*i);
                                this.map[i+1][j].stopAllActions();
                                this.map[i+1][j].runAction(cc.sequence(cc.moveTo(0.1,pos),cc.removeSelf(true)));
                                this.map[i+1][j]=null;
                                console.log(this.map[i][j].getComponent("item")._score) 
                                this.map[i][j].getComponent("item").setData(this.map[i][j].getComponent("item")._score)   
                            }
                        }
                    }
                }
                this.move(direction);
                break;
            case DIRECTION.LEFT:
                for (var i = 0; i < this.hang; i++) {
                    for (var j = 0; j < this.lie-1; j++) {
                        if (this.map[i][j]&&this.map[i][j + 1]) {
                            // console.log(this.map[i][j].getComponent("item")._score+"*********"+this.map[i][j + 1].getComponent("item")._score) 

                            if(this.map[i][j].getComponent("item")._score === this.map[i][j + 1].getComponent("item")._score)
                            {
                                this.map[i][j].getComponent("item")._score *= 2;
                                var pos=cc.p(85+124.5*j,198+145*i);
                                this.map[i][j+1].stopAllActions();
                                this.map[i][j+1].runAction(cc.sequence(cc.moveTo(0.1,pos),cc.removeSelf(true)));
                                this.map[i][j + 1]=null;
                                console.log(this.map[i][j].getComponent("item")._score) 
                                this.map[i][j].getComponent("item").setData(this.map[i][j].getComponent("item")._score)   
                            }
                        }
                    }
                }
                this.move(direction);
                break;
            case DIRECTION.RIGHT:
                for (var i = 0; i < this.hang; i++) {
                    for (var j = this.lie-1 ; j >0 ; j--) {
                        if (this.map[i][j]&&this.map[i][j - 1]) {
                            // console.log(this.map[i][j].getComponent("item")._score+"*********"+this.map[i][j - 1].getComponent("item")._score) 
                            if(this.map[i][j].getComponent("item")._score === this.map[i][j - 1].getComponent("item")._score)
                            {
                                this.map[i][j].getComponent("item")._score *= 2;
                                var pos=cc.p(85+124.5*j,198+145*i);
                                this.map[i][j-1].stopAllActions();
                                this.map[i][j-1].runAction(cc.sequence(cc.moveTo(0.1,pos),cc.removeSelf(true)));
                                this.map[i][j - 1]=null;
                                console.log(this.map[i][j].getComponent("item")._score) 
                                this.map[i][j].getComponent("item").setData(this.map[i][j].getComponent("item")._score) 
                            }

                        }
                    }
                }
                this.move(direction);
                break;
        }
    },
    createBlockByNum:function (num) {
        if(this._reStart)
        {
            this._reStart=false;
            return;
        }
        for(var i=0;i<num;i++)
        {
            if(num>=2)
            {
                var index=this.getSeedRandom(8,this.emptyMap.length);
            }else
            {
                var index=this.getSeedRandom(0,this.emptyMap.length);
            }
            var random=this.getSeedRandom(0,100);
            var score=random>=70?4:2;
            var obj = this.emptyMap[index];
            this.emptyMap.splice(index,1);
            var block = cc.instantiate(this.item);
            block.getComponent("item").setData(score)
            block.setPosition(85+124.5*obj.lie,198+145*obj.hang);
            this.spriteNode.node.addChild(block,1000);
            this.map[obj.hang][obj.lie]=block;
        }
        this.resetEmptyMap();
    },
    getSeedRandom:function(min,max){
        max = max || 1;
        min = min || 0;
        var currSeed=new Date().getTime()
        currSeed = (currSeed * 9301 + 49297) % 233280;
        var rnd = currSeed / 233280.0;
        var tmp = min + rnd * (max - min);
        return parseInt(tmp);
    },
    /**
     * 找到数组不为空的元素
     * @returns {Array}
     */
    getBlockArr:function () {
        var blockArr=[];
        for (var i = 0; i < this.hang; i++) {
            for (var j = 0; j < this.lie; j++) {
                if (this.map[i][j]) {
                    blockArr.push({
                        indexArr: [i, j],
                        block:this.map[i][j]
                    });
                }
            }
        }
        return blockArr;
    },
    isGameEnd:function () {
        if(!this.canGoDown()&&!this.canGoLeft()&&!this.canGoRight()&&!this.canGoUp())
        {
            return true;
        }
        return false;
    },
    // onLoad () {},
    getDirection:function (startPoint,lastPoint) {
        var point=lastPoint.sub(startPoint) //cc.pSub(lastPoint,startPoint);
        var j_point=cc.v2(Math.abs(point.x),Math.abs(point.y));
        if(j_point.x<=10&&j_point.y<=10)
        {
            return DIRECTION.NONE;
        }else if(point.x>0&&j_point.x>j_point.y)
        {
            return DIRECTION.RIGHT;

        }else if(point.x<0&&j_point.x>j_point.y)
        {
            return DIRECTION.LEFT;

        }else if(point.y>0&&j_point.y>j_point.x)
        {
            return DIRECTION.UP;
        }else if(point.y<0&&j_point.y>j_point.x)
        {
            return DIRECTION.DOWN;
        }
    },
    start () {
        var self=this
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) 
        { 
            return true;    
        },this.node);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (event) 
        { 
   
        },this.node);
        this.node.on(cc.Node.EventType.TOUCH_END, function (event) 
        { 
            
            var node=event.getCurrentTarget();
            var startPoint=event.getStartLocation();
            var currPoint=event.getLocation();
            node._direction=self.getDirection(startPoint,currPoint);
            self.go(node._direction);
            self._touch=false;
               
        },this.node);
        this.initMap()
        

    },
    getBack(){//返回
       cc.director.loadScene('gameStar')
    },
    update() {
        
    },
});
